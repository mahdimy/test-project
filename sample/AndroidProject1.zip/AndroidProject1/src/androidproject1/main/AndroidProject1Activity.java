package androidproject1.main;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
 
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
 
public class AndroidProject1Activity extends Activity
{
    // URL of ePOS-Print supported TM printer (Version 4.1 or later)
    //private static String address = "http://192.168.192.168/cgi-bin/epos/service.cgi";

    // URL of ePOS-Print supported TM printer
    private static String address = "http://192.168.192.168/cgi-bin/epos/service.cgi?devid=local_printer&timeout=10000";

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button button = (Button) this.findViewById(R.id.button1);
        button.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {       
                try {
                    // Send print document
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httppost = new HttpPost(address);

                    // Create print document(String)
                    /*
                    String req = 
                    "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 
                        "<s:Header>" +
                            "<parameter xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>" +
                                "<devid>local_printer</devid>" +
                                "<timeout>10000</timeout>" +
                                "<printjobid>ABC123</printjobid>" +
                            "</parameter>" +
                        "</s:Header>" +
                        "<s:Body>" + 
                           "<epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>" +
                                "<text lang='en' smooth='true'>Intelligent Printer&#10;</text>" +
                                "<barcode type='ean13' width='2' height='48'>201234567890</barcode>" +
                                "<feed unit='24' />" +
                                "<image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>" + 
                                "<cut />" +
                            "</epos-print>" +
                        "</s:Body>" + 
                    "</s:Envelope>";
                    */

                    // Create print document(String)
                    String req = 
                    "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">" + 
                        "<s:Body>" + 
                           "<epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>" +
                                "<text lang='en' smooth='true'>Intelligent Printer&#10;</text>" +
                                "<barcode type='ean13' width='2' height='48'>201234567890</barcode>" +
                                "<feed unit='24' />" +
                                "<image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>" + 
                                "<cut />" +
                            "</epos-print>" +
                        "</s:Body>" + 
                    "</s:Envelope>";

                    StringEntity entity = new StringEntity(req, HTTP.UTF_8);
                    entity.setContentType("text/xml; charset=utf-8");
                    httppost.setEntity(entity);
                    httppost.setHeader("SOAPAction", "\"\"");

                    HttpResponse response = httpclient.execute(httppost);

                    // Receive response document
                    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder builder = factory.newDocumentBuilder();                     

                    // Parse response document(DOM)
                    Document doc = builder.parse(response.getEntity().getContent());
                    Element el = (Element)doc.getElementsByTagName("response").item(0);
                    AlertDialog.Builder dlg = new AlertDialog.Builder(AndroidProject1Activity.this);
                    dlg.setTitle("AndroidProject1Activity");
                    dlg.setMessage(el.getAttribute("success"));
                    dlg.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dlg , int whichbutton) {
                            setResult(RESULT_OK);
                        }
                    });
                    dlg.create();
                    dlg.show(); 
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        });
    }
}