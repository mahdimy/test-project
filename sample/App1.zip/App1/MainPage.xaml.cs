﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Xml.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace App1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // URL of ePOS-Print supported TM printer (Version 4.1 or later)
        //private string address = "http://192.168.192.168/cgi-bin/epos/service.cgi";

        // URL of ePOS-Print supported TM printer
        private string address = "http://192.168.192.168/cgi-bin/epos/service.cgi?devid=local_printer&timeout=10000";

        // XML namespace
        private XNamespace soap = "http://schemas.xmlsoap.org/soap/envelope/";
        private XNamespace epos = "http://www.epson-pos.com/schemas/2011/03/epos-print";

        public MainPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            // Create print document (LINQ to XML)
            XElement req =
                new XElement(soap + "Envelope",
                    new XElement(soap + "Body",
                        new XElement(epos + "epos-print",
                            new XElement(epos + "text", "Intelligent Printer\n",
                                new XAttribute("lang", "en"),
                                new XAttribute("smooth", "true")),
                            new XElement(epos + "barcode", "201234567890",
                                new XAttribute("type", "ean13"),
                                new XAttribute("width", "2"),
                                new XAttribute("height", "48")),
                            new XElement(epos + "feed",
                                new XAttribute("unit", "24")),
                            new XElement(epos + "image", "8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P",
                                new XAttribute("width", "8"),
                                new XAttribute("height", "48")),
                            new XElement(epos + "cut"))));
            HttpContent content = new StringContent(req.ToString());

            // Create print document (String, Version 4.1 or later)
            /*
            string req = @"
                <s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>
                    <s:Header>
                        <parameter xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>
                            <devid>local_printer</devid>
                            <timeout>10000</timeout>
                            <printjobid>ABC123</printjobid>
                        </parameter>
                    </s:Header>
                    <s:Body>
                        <epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>
                            <text lang='en' smooth='true'>Intelligent Printer&#10;</text>
                            <barcode type='ean13' width='2' height='48'>201234567890</barcode>
                            <feed unit='24'/>
                            <image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>
                            <cut/>
                        </epos-print>
                    </s:Body>
                </s:Envelope>
            ";
            HttpContent content = new StringContent(req);
            */

            // Create print document (String)
            /*
            string req = @"
                <s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>
                    <s:Body>
                        <epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>
                            <text lang='en' smooth='true'>Intelligent Printer&#10;</text>
                            <barcode type='ean13' width='2' height='48'>201234567890</barcode>
                            <feed unit='24'/>
                            <image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>
                            <cut/>
                        </epos-print>
                    </s:Body>
                </s:Envelope>
            ";
            HttpContent content = new StringContent(req);
            */

            // Send print document
            HttpClient client = new HttpClient();
            content.Headers.ContentType = MediaTypeHeaderValue.Parse("text/xml; charset=utf-8");
            content.Headers.Add("SOAPAction", "\"\"");
            HttpResponseMessage msg = await client.PostAsync(address, content);

            // Receive response document
            XElement res = XElement.Parse(await msg.Content.ReadAsStringAsync());

            // Parse response document
            var c = from el in res.Descendants(epos + "response") select el.Attribute("success");
            MessageDialog dialog = new MessageDialog(c.First().Value);
            await dialog.ShowAsync();
        }
    }
}
