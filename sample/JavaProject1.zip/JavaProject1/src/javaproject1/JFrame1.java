package javaproject1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
//import javax.xml.stream.XMLOutputFactory;
//import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class JFrame1 extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;

	// URL of ePOS-Print supported TM printer (Version 4.1 or later)
	//private static String address = "http://192.168.192.168/cgi-bin/epos/service.cgi";

	// URL of ePOS-Print supported TM printer
	private static String address = "http://192.168.192.168/cgi-bin/epos/service.cgi?devid=local_printer&timeout=10000";

	// XML namespace
	//private static String soap = "http://schemas.xmlsoap.org/soap/envelope/";
	private static String epos = "http://www.epson-pos.com/schemas/2011/03/epos-print";

	public JFrame1() {
		JButton button = new JButton("Print");
		button.addActionListener(this);
		this.setSize(300, 300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationByPlatform(true);
		this.add(button);
		this.setVisible(true);
	}

	public void actionPerformed(ActionEvent arg0) {
		try {
			// Send print document
			URL url = new URL(address);
			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
			conn.setRequestProperty("SOAPAction", "\"\"");

			// Create print document(StAX)
			/*
			XMLOutputFactory f1 = XMLOutputFactory.newInstance();
			XMLStreamWriter w = f1.createXMLStreamWriter(conn.getOutputStream(), "utf-8");
			w.writeStartDocument("utf-8", "1.0");
			w.writeStartElement("Envelope");
			w.writeDefaultNamespace(soap);
			w.writeStartElement("Body");
			w.writeStartElement("epos-print");
			w.writeDefaultNamespace(epos);
			w.writeStartElement("text");
			w.writeAttribute("lang", "en");
			w.writeAttribute("smooth", "true");
			w.writeCharacters("Intelligent Printer\n");
			w.writeEndElement();
			w.writeStartElement("barcode");
			w.writeAttribute("type", "ean13");
			w.writeAttribute("width", "2");
			w.writeAttribute("height", "48");
			w.writeCharacters("201234567890");
			w.writeEndElement();
			w.writeStartElement("feed");
			w.writeAttribute("unit", "24");
			w.writeEndElement();
			w.writeStartElement("image");
			w.writeAttribute("width", "8");
			w.writeAttribute("height", "48");
			w.writeCharacters("8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P");
			w.writeEndElement();
			w.writeEmptyElement("cut");
			w.writeEndElement();
			w.writeEndElement();
			w.writeEndElement();
			w.writeEndDocument();
			w.close();
			*/

			// Create print document (String, Version 4.1 or later)
			/*
			String req = 
				"<s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>" +
					"<s:Header>" +
						"<parameter xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>" +
							"<devid>local_printer</devid>" +
							"<timeout>10000</timeout>" +
							"<printjobid>ABC123</printjobid>" +
						"</parameter>" +
					"</s:Header>" +
					"<s:Body>" +
						"<epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>" +
							"<text lang='en' smooth='true'>Intelligent Printer&#10;</text>" +
							"<barcode type='ean13' width='2' height='48'>201234567890</barcode>" +
							"<feed unit='24' />" +
							"<image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>" + 
							"<cut />" +
						"</epos-print>" +
					"</s:Body>" +
				"</s:Envelope>";
			OutputStreamWriter w = new OutputStreamWriter(conn.getOutputStream(), "utf-8");
			w.write(req);
			w.close();
			*/
			
			// Create print document (String)
			///*
			String req = 
				"<s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>" +
					"<s:Body>" +
						"<epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>" +
							"<text lang='en' smooth='true'>Intelligent Printer&#10;</text>" +
							"<barcode type='ean13' width='2' height='48'>201234567890</barcode>" +
							"<feed unit='24' />" +
							"<image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>" + 
							"<cut />" +
						"</epos-print>" +
					"</s:Body>" +
				"</s:Envelope>";
			OutputStreamWriter w = new OutputStreamWriter(conn.getOutputStream(), "utf-8");
			w.write(req);
			w.close();
			//*/
			
			conn.connect();

			// Receive response document
			StreamSource source = new StreamSource(conn.getInputStream());
			DOMResult result = new DOMResult();
			TransformerFactory f2 = TransformerFactory.newInstance();
			Transformer t = f2.newTransformer();
			t.transform(source, result);

			// Parse response document (DOM)
			Document doc = (Document)result.getNode();
			Element el = (Element)doc.getElementsByTagNameNS(epos, "response").item(0);
			JOptionPane.showMessageDialog(null, el.getAttribute("success"));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new JFrame1();
	}
}
