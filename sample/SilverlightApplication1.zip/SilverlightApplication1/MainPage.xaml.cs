﻿using System;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;

namespace SilverlightApplication1
{
    public partial class MainPage : UserControl
    {
        // URL of ePOS-Print supported TM printer (Version 4.1 or later)
        //private string address = "http://192.168.192.168/cgi-bin/epos/service.cgi";

        // URL of ePOS-Print supported TM printer
        private string address = "http://192.168.192.168/cgi-bin/epos/service.cgi?devid=local_printer&timeout=10000";

        // XML namespace
        private XNamespace soap = "http://schemas.xmlsoap.org/soap/envelope/";
        private XNamespace epos = "http://www.epson-pos.com/schemas/2011/03/epos-print";

        public MainPage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            // Create print document (LINQ to XML)
            XElement req =
                new XElement(soap + "Envelope",
                    new XElement(soap + "Body",
                        new XElement(epos + "epos-print",
                            new XElement(epos + "text", "Intelligent Printer\n",
                                new XAttribute("lang", "en"),
                                new XAttribute("smooth", "true")),
                            new XElement(epos + "barcode", "201234567890",
                                new XAttribute("type", "ean13"),
                                new XAttribute("width", "2"),
                                new XAttribute("height", "48")),
                            new XElement(epos + "feed",
                                new XAttribute("unit", "24")),
                            new XElement(epos + "image", "8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P",
                                new XAttribute("width", "8"),
                                new XAttribute("height", "48")),
                            new XElement(epos + "cut"))));

            // Create print document (String, Version 4.1 or later)
            /*
            string req = @"
                <s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>
                    <s:Header>
                        <parameter xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>
                            <devid>local_printer</devid>
                            <timeout>10000</timeout>
                            <printjobid>ABC123</printjobid>
                        </parameter>
                    </s:Header>
                    <s:Body>
                        <epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>
                            <text lang='en' smooth='true'>Intelligent Printer&#10;</text>
                            <barcode type='ean13' width='2' height='48'>201234567890</barcode>
                            <feed unit='24'/>
                            <image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>
                            <cut/>
                        </epos-print>
                    </s:Body>
                </s:Envelope>
            ";
            */

            // Create print document (String)
            /*
            string req = @"
                <s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>
                    <s:Body>
                        <epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>
                            <text lang='en' smooth='true'>Intelligent Printer&#10;</text>
                            <barcode type='ean13' width='2' height='48'>201234567890</barcode>
                            <feed unit='24'/>
                            <image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>
                            <cut/>
                        </epos-print>
                    </s:Body>
                </s:Envelope>
            ";
            */

            // Send print document
            WebClient client = new WebClient();
            client.Headers["Content-Type"] = "text/xml; charset=utf-8";
            client.UploadStringCompleted +=
                new UploadStringCompletedEventHandler(client_UploadStringCompleted);
            client.UploadStringAsync(new Uri(address, UriKind.Absolute), req.ToString());
        }

        // Receive response document
        void client_UploadStringCompleted(object sender, UploadStringCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                MessageBox.Show(e.Error.Message);
            }
            else
            {
                // Parse response document
                XElement res = XElement.Parse(e.Result);
                var c = from el in res.Descendants(epos + "response") select el.Attribute("success");
                MessageBox.Show(c.First().Value);
            }
        }
    }
}
