﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;
using System.Windows.Forms;

namespace SmartDeviceProject1
{
    public partial class Form1 : Form
    {
        // URL of ePOS-Print supported TM printer (Version 4.1 or later)
        //private string address = "http://192.168.192.168/cgi-bin/epos/service.cgi";

        // URL of ePOS-Print supported TM printer
        private string address = "http://192.168.192.168/cgi-bin/epos/service.cgi?devid=local_printer&timeout=10000";

        // XML namespace
        //private string soap = "http://schemas.xmlsoap.org/soap/envelope/";
        private string epos = "http://www.epson-pos.com/schemas/2011/03/epos-print";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Create print document (Version 4.1 or later)
            /*
            string req = @"
                <s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>
                    <s:Header>
                        <parameter xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>
                            <devid>local_printer</devid>
                            <timeout>10000</timeout>
                            <printjobid>ABC123</printjobid>
                        </parameter>
                    </s:Header>
                    <s:Body>
                        <epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>
                            <text lang='en' smooth='true'>Intelligent Printer&#10;</text>
                            <barcode type='ean13' width='2' height='48'>201234567890</barcode>
                            <feed unit='24'/>
                            <image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>
                            <cut/>
                        </epos-print>
                    </s:Body>
                </s:Envelope>
            ";
            */

            // Create print document
            string req = @"
                <s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>
                    <s:Body>
                        <epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>
                            <text lang='en' smooth='true'>Intelligent Printer&#10;</text>
                            <barcode type='ean13' width='2' height='48'>201234567890</barcode>
                            <feed unit='24'/>
                            <image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>
                            <cut/>
                        </epos-print>
                    </s:Body>
                </s:Envelope>
            ";

            // Send print document
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(address);
            request.Method = "POST";
            request.ContentType = "text/xml; charset=utf-8";
            request.ContentLength = Encoding.UTF8.GetByteCount(req);
            request.Headers.Set("SOAPAction", "\"\"");
            StreamWriter w = new StreamWriter(request.GetRequestStream());
            w.Write(req);
            w.Close();

            // Receive response document
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader r = new StreamReader(response.GetResponseStream());
            string res = r.ReadToEnd();
            r.Close();

            // Parse response document
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(res);
            XmlElement el = (XmlElement)doc.GetElementsByTagName("response", epos).Item(0);
            MessageBox.Show(el.GetAttribute("success"));
        }
    }
}