﻿Imports System
Imports System.Linq
Imports System.Net
Imports System.Windows.Forms
Imports System.Xml.Linq

Public Class Form1

    ' URL of ePOS-Print supported TM printer (Version 4.1 or later)
    'Private address As String = "http://192.168.192.168/cgi-bin/epos/service.cgi"

    ' URL of ePOS-Print supported TM printer
    Private address As String = "http://192.168.192.168/cgi-bin/epos/service.cgi?devid=local_printer&timeout=10000"

    ' XML namespace
    Private soap As XNamespace = "http://schemas.xmlsoap.org/soap/envelope/"
    Private epos As XNamespace = "http://www.epson-pos.com/schemas/2011/03/epos-print"

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        ' Create print document (Version 4.1 or later)
        'Dim req As XElement = _
        '    <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
        '        <s:Header>
        '            <parameter xmlns="http://www.epson-pos.com/schemas/2011/03/epos-print">
        '                <devid>local_printer</devid>
        '                <timeout>10000</timeout>
        '                <printjobid>ABC123</printjobid>
        '            </parameter>
        '        </s:Header>
        '        <s:Body>
        '            <epos-print xmlns="http://www.epson-pos.com/schemas/2011/03/epos-print">
        '                <text lang="en" smooth="true">Intelligent Printer&#10;</text>
        '                <barcode type="ean13" width="2" height="48">201234567890</barcode>
        '                <feed unit="24"/>
        '                <image width="8" height="48">8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>
        '                <cut/>
        '            </epos-print>
        '        </s:Body>
        '    </s:Envelope>

        ' Create print document
        Dim req As XElement = _
            <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
                <s:Body>
                    <epos-print xmlns="http://www.epson-pos.com/schemas/2011/03/epos-print">
                        <text lang="en" smooth="true">Intelligent Printer&#10;</text>
                        <barcode type="ean13" width="2" height="48">201234567890</barcode>
                        <feed unit="24"/>
                        <image width="8" height="48">8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>
                        <cut/>
                    </epos-print>
                </s:Body>
            </s:Envelope>

        ' Send print document
        Dim client As WebClient = New WebClient()
        client.Encoding = System.Text.Encoding.UTF8
        client.Headers.Set("Content-Type", "text/xml; charset=utf-8")
        client.Headers.Set("SOAPAction", """""")
        AddHandler client.UploadStringCompleted, AddressOf UploadStringCompletedEventHandler
        client.UploadStringAsync(New Uri(address, UriKind.Absolute), req.ToString())

    End Sub

    ' Receive response document
    Private Sub UploadStringCompletedEventHandler(sender As Object, e As UploadStringCompletedEventArgs)

        If (e.Error IsNot Nothing) Then
            MessageBox.Show(e.Error.Message)
        Else
            'Parse response document
            Dim res As XElement = XElement.Parse(e.Result)
            Dim c = From el In res.Descendants(epos + "response") Select el.Attribute("success")
            MessageBox.Show(c.First().Value)
        End If

    End Sub

End Class

