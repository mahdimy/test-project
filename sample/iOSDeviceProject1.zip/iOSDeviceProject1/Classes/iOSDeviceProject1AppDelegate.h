//
//  iOSDeviceProject1AppDelegate.h
//  iOSDeviceProject1
//

#import <UIKit/UIKit.h>

@interface iOSDeviceProject1AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

