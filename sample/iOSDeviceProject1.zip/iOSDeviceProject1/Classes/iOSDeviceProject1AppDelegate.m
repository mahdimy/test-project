//
//  iOSDeviceProject1AppDelegate.m
//  iOSDeviceProject1
//

#import "iOSDeviceProject1AppDelegate.h"

@implementation iOSDeviceProject1AppDelegate

@synthesize window;


#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    

    CGRect rect = [[UIScreen mainScreen] bounds];
    self.window = [[UIWindow alloc] initWithFrame:rect];

    UIButton *btn = [[UIButton buttonWithType:UIButtonTypeRoundedRect] retain];
    [btn setTitle:@"print" forState:UIControlStateNormal];
    [btn setFrame:CGRectMake(110, 220, 100, 40)];
    [btn addTarget:self action:@selector(respondToButtonClick:)  forControlEvents:UIControlEventTouchDown];
    [self.window addSubview:btn];
    [btn release];

    [self.window makeKeyAndVisible];

    return YES;
}

-(void)respondToButtonClick:(UIButton*)button{

    // URL of ePOS-Print supported TM printer (Version 4.1 or later)
    //NSString *urlstr = @"http://192.168.192.168/cgi-bin/epos/service.cgi";
    // URL of ePOS-Print supported TM printer
    NSString *urlstr = @"http://192.168.192.168/cgi-bin/epos/service.cgi?devid=local_printer&timeout=10000";
    NSURL *url = [NSURL URLWithString:urlstr]; 

    // Create print document (Version 4.1 or later)
    /*
    NSString *content = 
        @"<s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>"
            "<s:Header>"
                "<parameter xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>"
                    "<devid>local_printer</devid>"
                    "<timeout>10000</timeout>"
                    "<printjobid>ABC123</printjobid>"
                "</parameter>"
            "</s:Header>"
            "<s:Body>"
                "<epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>"
                    "<text lang='en' smooth='true'>Intelligent Printer&#10;</text>"
                    "<barcode type='ean13' width='2' height='48'>201234567890</barcode>"
                    "<feed unit='24' />"
                    "<image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>"
                    "<cut />"
                "</epos-print>"
            "</s:Body>"
        "</s:Envelope>";
    */

    // Create print document
    NSString *content = 
        @"<s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/'>"
            "<s:Body>"
                "<epos-print xmlns='http://www.epson-pos.com/schemas/2011/03/epos-print'>"
                    "<text lang='en' smooth='true'>Intelligent Printer&#10;</text>"
                    "<barcode type='ean13' width='2' height='48'>201234567890</barcode>"
                    "<feed unit='24' />"
                    "<image width='8' height='48'>8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P8PDw8A8PDw/w8PDwDw8PD/Dw8PAPDw8P</image>"
                    "<cut />"
                "</epos-print>"
            "</s:Body>"
        "</s:Envelope>";

    // Send print document
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL: url];      
    [request setHTTPMethod: @"POST"];
    [request setValue:@"text/xml; charset=utf-8"forHTTPHeaderField:@"Content-Type"];     
    [request setValue:@"\"\""forHTTPHeaderField:@"SOAPAction"];     
    [request setHTTPBody:[content dataUsingEncoding:NSUTF8StringEncoding]]; 

    NSError *error;
    NSURLResponse *response;
    NSData *buffer = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];

    // Receive response document
    NSString *dataString = nil;
    dataString = [[NSString alloc] initWithData : buffer encoding : NSUTF8StringEncoding];

    NSLog(@"%@",dataString);

}

- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}


- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
