//
//  main.m
//  iOSDeviceProject1
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"iOSDeviceProject1AppDelegate");
    [pool release];
    return retVal;
}
